﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeekFiveLab
{
    class Game
    {

        #region properties 
        //public string Name{get;set;}

        private readonly string _name;
        // when a property is read-only, you can only assign it in the constructor
        public string Name
        {
            get
            {
                return _name;
            }
        }
        protected decimal Price { get; set; }
        public DateTime ReleaseDate { get; set; }
        #endregion properties 

        #region constructors
        public Game(string name, decimal price, DateTime releasedate)
        {
            _name = name;
            Price = price;
            ReleaseDate = releasedate;
        }
        
        public Game(string name, decimal price)
            :this(name,price, DateTime.Now)
        {

        }
        public override string ToString()
        {
            return string.Format($"{ Name } - { Price } - {ReleaseDate}");
        }

        public Game() : this("", 0) { }
        #endregion constructors
    }

    public class ComputerGame : Game
    {
        public string PEGI_RATING { get; set; }

        public ComputerGame(string name, decimal price, DateTime date, string pegi)
            :base(name, price, date)
        {
            PEGI_RATING = pegi;
        }
        public override string ToString()
        {
            return string.Format($"{ Name } - { Price } - {ReleaseDate}");
        }


        public decimal GetDiscountPrice()
        {
            return Price * .9m;
        }

    }

}
